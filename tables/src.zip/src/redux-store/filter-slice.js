import { createSlice } from '@reduxjs/toolkit'
const initialState = {

}

const filterSlice = createSlice({
    name: "filters",
    initialState: {},
    reducers: {
        updateQuery: (state, payload) => {

        }
    }

})

export const { updateQuery } = filterSlice.actions;
export default filterSlice.reducer;